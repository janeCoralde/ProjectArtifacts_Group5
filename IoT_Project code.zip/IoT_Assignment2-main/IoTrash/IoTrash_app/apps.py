from django.apps import AppConfig


class IotrashAppConfig(AppConfig):
    name = 'IoTrash_app'
