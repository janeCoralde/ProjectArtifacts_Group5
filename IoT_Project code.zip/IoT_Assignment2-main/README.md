# IoT_Assignment2

Django application for proposed IoTrash application. 
To run, in command prompt (make sure that directory is set in project): enter command **py manage.py runserver**
This will automatically deploy the web application in 127.0.0.1:8000. 

In order to log in the admin page, please use localhost:8000/admin/ and use provided credentials in the report.
To create a new user with superuser status (admin), please use command **py manage.py createsuperuser**
